# Run and troubleshoot (quick guide)

## IntelliJ IDEA
1. Extract this ZIP.
2. IntelliJ: File → Open → choose the `Nandigram_Student_Portal_DB` folder (the one containing `pom.xml`).
3. Wait for Maven import and JDK 17 setup to finish.
4. Open `src/main/java/in/nandigram/portal/StudentPortalApplication.java` and press Run.
5. Before running, set environment variables in Run → Edit Configurations → Environment variables:
   `AUTHOR_USERNAME=MdAzeem;AUTHOR_PASSWORD=Azeem@1122`
6. Visit `http://localhost:8080`.

If Maven is not installed, IntelliJ's bundled Maven can be selected in Settings → Build Tools → Maven. Use JDK 17.

## Source structure
- `src/main/java/in/nandigram/portal/StudentPortalApplication.java` — app startup and demo student seeding.
- `PortalController.java` — login, profile, marks, upload/download and delete APIs.
- `Student.java` — database entity/table mapping.
- `StudentRepository.java` — database CRUD access.
- `src/main/resources/static/index.html` — structured HTML page.
- `style.css` — layout and responsive styling.
- `app.js` — frontend interactions and API requests.
- `application.properties` — port and database settings.

This is a college/demo portal. Change demo passwords and add production-grade security before storing real student records.
