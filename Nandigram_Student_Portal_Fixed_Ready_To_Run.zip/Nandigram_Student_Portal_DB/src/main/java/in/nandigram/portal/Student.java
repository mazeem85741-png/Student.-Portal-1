package in.nandigram.portal;

import jakarta.persistence.*;

@Entity
@Table(name = "students")
public class Student {
    @Id
    @Column(length = 40)
    private String username;
    @Column(nullable = false, length = 100)
    private String passwordHash;
    private String fullName;
    private String admissionNo;
    private String course;
    private String className;
    private String phone;
    private String email;
    @Column(length = 3000)
    private String address;
    @Column(columnDefinition = "text")
    private String subjectMarks = "[]";
    @Column(columnDefinition = "text")
    private String testMarks = "[]";
    @Column(columnDefinition = "text")
    private String documents = "[]";
    private String photo;

    public String getUsername(){return username;} public void setUsername(String v){username=v;}
    public String getPasswordHash(){return passwordHash;} public void setPasswordHash(String v){passwordHash=v;}
    public String getFullName(){return fullName;} public void setFullName(String v){fullName=v;}
    public String getAdmissionNo(){return admissionNo;} public void setAdmissionNo(String v){admissionNo=v;}
    public String getCourse(){return course;} public void setCourse(String v){course=v;}
    public String getClassName(){return className;} public void setClassName(String v){className=v;}
    public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getAddress(){return address;} public void setAddress(String v){address=v;}
    public String getSubjectMarks(){return subjectMarks;} public void setSubjectMarks(String v){subjectMarks=v;}
    public String getTestMarks(){return testMarks;} public void setTestMarks(String v){testMarks=v;}
    public String getDocuments(){return documents;} public void setDocuments(String v){documents=v;}
    public String getPhoto(){return photo;} public void setPhoto(String v){photo=v;}
}
