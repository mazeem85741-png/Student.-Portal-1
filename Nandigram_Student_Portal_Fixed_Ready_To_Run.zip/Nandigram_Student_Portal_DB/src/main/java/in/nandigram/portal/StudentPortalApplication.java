package in.nandigram.portal;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class StudentPortalApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentPortalApplication.class, args);
    }

    @Bean
    CommandLineRunner seedStudents(StudentRepository repository) {
        return args -> {
            String[] names = {"KALAM", "MUBASSHIR", "HURIYA", "AYESHA", "RAYYAN"};
            for (int i = 0; i < names.length; i++) {
                final int index = i;
                String name = names[i];
                if (!repository.existsById(name)) {
                    Student student = new Student();
                    student.setUsername(name);
                    student.setPasswordHash(new BCryptPasswordEncoder().encode("1122"));
                    student.setFullName(name);
                    student.setAdmissionNo("NII-" + (1001 + index));
                    student.setCourse("Information Technology");
                    student.setClassName("");
                    student.setPhone("");
                    student.setEmail("");
                    student.setAddress("");
                    student.setSubjectMarks("[]");
                    student.setTestMarks("[]");
                    student.setDocuments("[]");
                    student.setPhoto("");
                    repository.save(student);
                }
            }
        };
    }
}
