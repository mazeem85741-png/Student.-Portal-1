package in.nandigram.portal;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

@RestController
@RequestMapping("/api")
public class PortalController {
    private final StudentRepository repository;
    private final ObjectMapper mapper;
    private final Path uploadRoot = Paths.get(System.getenv().getOrDefault("UPLOAD_DIR", "uploads")).toAbsolutePath();

    public PortalController(StudentRepository repository, ObjectMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
        try { Files.createDirectories(uploadRoot); } catch (IOException e) { throw new RuntimeException(e); }
    }

    private boolean author(HttpSession session) { return "AUTHOR".equals(session.getAttribute("role")); }
    private String currentStudent(HttpSession session) {
        return "STUDENT".equals(session.getAttribute("role")) ? (String) session.getAttribute("username") : null;
    }
    private ResponseEntity<?> unauthorized() { return ResponseEntity.status(401).body(Map.of("error", "Please log in first.")); }
    private String authorUsername() { return System.getenv().getOrDefault("AUTHOR_USERNAME", "MdAzeem"); }
    private String authorPassword() { return System.getenv().getOrDefault("AUTHOR_PASSWORD", ""); }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> body, HttpSession session) {
        String username = body.getOrDefault("username", "").trim();
        String password = body.getOrDefault("password", "");
        if (username.equalsIgnoreCase(authorUsername()) && !authorPassword().isBlank() && password.equals(authorPassword())) {
            session.setAttribute("role", "AUTHOR"); session.setAttribute("username", authorUsername());
            return ResponseEntity.ok(Map.of("role", "AUTHOR", "username", authorUsername()));
        }
        String key = username.toUpperCase(Locale.ROOT);
        Optional<Student> found = repository.findById(key);
        if (found.isPresent() && new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder().matches(password, found.get().getPasswordHash())) {
            session.setAttribute("role", "STUDENT"); session.setAttribute("username", key);
            return ResponseEntity.ok(Map.of("role", "STUDENT", "username", key));
        }
        return ResponseEntity.status(401).body(Map.of("error", "Username or password is incorrect."));
    }

    @PostMapping("/logout")
    public Map<String,String> logout(HttpSession session) { session.invalidate(); return Map.of("message", "Logged out"); }

    @GetMapping("/me")
    public ResponseEntity<?> me(HttpSession session) {
        if (session.getAttribute("role") == null) return unauthorized();
        return ResponseEntity.ok(Map.of("role", session.getAttribute("role"), "username", session.getAttribute("username")));
    }

    @GetMapping("/students")
    public ResponseEntity<?> allStudents(HttpSession session) {
        if (!author(session)) return ResponseEntity.status(403).body(Map.of("error", "Author access only."));
        return ResponseEntity.ok(repository.findAll().stream().map(this::toMap).toList());
    }

    @GetMapping("/students/{username}")
    public ResponseEntity<?> oneStudent(@PathVariable String username, HttpSession session) {
        String key = username.toUpperCase(Locale.ROOT);
        if (!author(session) && !key.equals(currentStudent(session))) return ResponseEntity.status(403).body(Map.of("error", "You can only view your own profile."));
        return repository.findById(key).<ResponseEntity<?>>map(s -> ResponseEntity.ok(toMap(s))).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/students/{username}")
    public ResponseEntity<?> updateStudent(@PathVariable String username, @RequestBody Map<String,Object> body, HttpSession session) throws IOException {
        if (!author(session)) return ResponseEntity.status(403).body(Map.of("error", "Only the author can edit student details."));
        String key = username.toUpperCase(Locale.ROOT);
        Student s = repository.findById(key).orElse(null);
        if (s == null) return ResponseEntity.notFound().build();
        if (body.containsKey("fullName")) s.setFullName(str(body.get("fullName")));
        if (body.containsKey("admissionNo")) s.setAdmissionNo(str(body.get("admissionNo")));
        if (body.containsKey("course")) s.setCourse(str(body.get("course")));
        if (body.containsKey("className")) s.setClassName(str(body.get("className")));
        if (body.containsKey("phone")) s.setPhone(str(body.get("phone")));
        if (body.containsKey("email")) s.setEmail(str(body.get("email")));
        if (body.containsKey("address")) s.setAddress(str(body.get("address")));
        if (body.containsKey("subjectMarks")) s.setSubjectMarks(mapper.writeValueAsString(body.get("subjectMarks")));
        if (body.containsKey("testMarks")) s.setTestMarks(mapper.writeValueAsString(body.get("testMarks")));
        repository.save(s);
        return ResponseEntity.ok(toMap(s));
    }

    @PostMapping("/students/{username}/documents")
    public ResponseEntity<?> uploadDocument(@PathVariable String username, @RequestParam("file") MultipartFile file,
                                            @RequestParam(defaultValue = "document") String kind, HttpSession session) throws IOException {
        if (!author(session)) return ResponseEntity.status(403).body(Map.of("error", "Only the author can upload documents."));
        String key = username.toUpperCase(Locale.ROOT);
        Student student = repository.findById(key).orElse(null);
        if (student == null) return ResponseEntity.notFound().build();
        if (file.isEmpty()) return ResponseEntity.badRequest().body(Map.of("error", "Choose a file first."));
        String original = StringUtils.cleanPath(Objects.requireNonNull(file.getOriginalFilename()));
        String ext = "";
        int dot = original.lastIndexOf('.');
        if (dot >= 0) ext = original.substring(dot).toLowerCase(Locale.ROOT);
        Set<String> allowed = Set.of(".pdf", ".doc", ".docx", ".xls", ".xlsx", ".json", ".jpg", ".jpeg", ".png", ".txt", ".csv");
        if (!allowed.contains(ext)) return ResponseEntity.badRequest().body(Map.of("error", "File type not allowed."));
        String id = UUID.randomUUID().toString();
        Path folder = uploadRoot.resolve(key).normalize();
        Files.createDirectories(folder);
        Path target = folder.resolve(id + ext).normalize();
        if (!target.startsWith(folder)) return ResponseEntity.badRequest().build();
        file.transferTo(target);
        Map<String,Object> doc = new LinkedHashMap<>();
        doc.put("id", id); doc.put("name", original); doc.put("kind", kind); doc.put("size", file.getSize());
        doc.put("downloadUrl", "/api/documents/" + key + "/" + id);
        List<Map<String,Object>> docs = docs(student);
        docs.add(doc);
        student.setDocuments(mapper.writeValueAsString(docs));
        if ("photo".equals(kind) && (ext.equals(".jpg") || ext.equals(".jpeg") || ext.equals(".png")))
            student.setPhoto("/api/photos/" + key + "/" + id);
        repository.save(student);
        return ResponseEntity.ok(doc);
    }

    @GetMapping("/documents/{username}/{id}")
    public ResponseEntity<Resource> download(@PathVariable String username, @PathVariable String id, HttpSession session) throws IOException {
        String key = username.toUpperCase(Locale.ROOT);
        if (!author(session) && !key.equals(currentStudent(session))) return ResponseEntity.status(403).build();
        Student student = repository.findById(key).orElse(null);
        if (student == null) return ResponseEntity.notFound().build();
        Map<String,Object> doc = docs(student).stream().filter(d -> id.equals(d.get("id"))).findFirst().orElse(null);
        if (doc == null) return ResponseEntity.notFound().build();
        Path file = findFile(key, id);
        if (file == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + doc.get("name").toString().replace("\"", "") + "\"")
            .body(new FileSystemResource(file));
    }

    @GetMapping("/photos/{username}/{id}")
    public ResponseEntity<Resource> photo(@PathVariable String username, @PathVariable String id, HttpSession session) throws IOException {
        String key = username.toUpperCase(Locale.ROOT);
        if (!author(session) && !key.equals(currentStudent(session))) return ResponseEntity.status(403).build();
        if (repository.findById(key).isEmpty()) return ResponseEntity.notFound().build();
        Path file = findFile(key, id);
        if (file == null) return ResponseEntity.notFound().build();
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        MediaType type = name.endsWith(".png") ? MediaType.IMAGE_PNG : MediaType.IMAGE_JPEG;
        return ResponseEntity.ok().contentType(type).body(new FileSystemResource(file));
    }

    @DeleteMapping("/students/{username}/documents/{id}")
    public ResponseEntity<?> deleteDocument(@PathVariable String username, @PathVariable String id, HttpSession session) throws IOException {
        if (!author(session)) return ResponseEntity.status(403).body(Map.of("error", "Only the author can delete documents."));
        String key = username.toUpperCase(Locale.ROOT);
        Student student = repository.findById(key).orElse(null);
        if (student == null) return ResponseEntity.notFound().build();
        List<Map<String,Object>> docs = docs(student);
        Map<String,Object> doc = docs.stream().filter(d -> id.equals(d.get("id"))).findFirst().orElse(null);
        if (doc == null) return ResponseEntity.notFound().build();
        Path file = findFile(key, id);
        if (file != null) Files.deleteIfExists(file);
        docs.remove(doc); student.setDocuments(write(docs));
        if (("/api/photos/" + key + "/" + id).equals(student.getPhoto())) student.setPhoto("");
        repository.save(student);
        return ResponseEntity.ok(Map.of("message", "Document deleted."));
    }

    private String str(Object value) { return value == null ? "" : String.valueOf(value); }
    private List<Map<String,Object>> docs(Student s) throws IOException {
        if (s.getDocuments() == null || s.getDocuments().isBlank()) return new ArrayList<>();
        return mapper.readValue(s.getDocuments(), new TypeReference<List<Map<String,Object>>>() {});
    }
    private String write(Object value) {
        try { return mapper.writeValueAsString(value); } catch (Exception e) { throw new RuntimeException(e); }
    }
    private Path findFile(String username, String id) throws IOException {
        Path folder = uploadRoot.resolve(username).normalize();
        if (!Files.exists(folder)) return null;
        try (var paths = Files.list(folder)) {
            return paths.filter(p -> p.getFileName().toString().startsWith(id + ".")).findFirst().orElse(null);
        }
    }
    private Map<String,Object> toMap(Student s) {
        Map<String,Object> m = new LinkedHashMap<>();
        m.put("username",s.getUsername()); m.put("fullName",s.getFullName()); m.put("admissionNo",s.getAdmissionNo());
        m.put("course",s.getCourse()); m.put("className",s.getClassName()); m.put("phone",s.getPhone()); m.put("email",s.getEmail());
        m.put("address",s.getAddress()); m.put("photo",s.getPhoto());
        try { m.put("subjectMarks", mapper.readValue(s.getSubjectMarks()==null?"[]":s.getSubjectMarks(), new TypeReference<List<Map<String,Object>>>(){})); } catch(Exception e){m.put("subjectMarks",List.of());}
        try { m.put("testMarks", mapper.readValue(s.getTestMarks()==null?"[]":s.getTestMarks(), new TypeReference<List<Map<String,Object>>>(){})); } catch(Exception e){m.put("testMarks",List.of());}
        try { m.put("documents", docs(s)); } catch(Exception e){m.put("documents",List.of());}
        return m;
    }
}
