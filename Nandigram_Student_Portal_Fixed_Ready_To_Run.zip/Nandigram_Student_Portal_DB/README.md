# Nandigram Institute of Information Technology — Student Portal (Database version)

Beginner-friendly Java + Spring Boot + HTML/CSS/JavaScript project. It now runs locally with a persistent H2 file database by default, and can use PostgreSQL through environment variables.

## Features
- PostgreSQL stores student profile details, hashed student passwords, marks and document metadata.
- Five student accounts: KALAM, MUBASSHIR, HURIYA, AYESHA, RAYYAN.
- Student password is `1122` for each seeded account.
- Author login can edit profiles, add subject/test marks, upload/delete documents and set profile photos.
- Students can only see their own profile and download their own documents.
- Supported uploads: PDF, DOC/DOCX, XLS/XLSX, JSON, JPG/JPEG, PNG, TXT and CSV.
- Uploaded file bytes are saved on disk; database stores their metadata.

## Author credentials
- Username: `MdAzeem`
- Password: set the `AUTHOR_PASSWORD` environment variable. For local demo set it to `Azeem@1122`.
- Never commit passwords to GitHub.

## Run locally
Requirements: Java 17+ and Maven 3.9+. PostgreSQL is optional for local demo because H2 is configured by default.

1. Open the project folder in IntelliJ IDEA and allow Maven to load dependencies.
2. Run `src/main/java/in/nandigram/portal/StudentPortalApplication.java`, or run `mvn spring-boot:run` in the project terminal.
3. Open http://localhost:8080.

### Demo login
- Author username: `MdAzeem`
- Author password: `Azeem@1122` (set `AUTHOR_PASSWORD` to this value before running)
- Student usernames: `KALAM`, `MUBASSHIR`, `HURIYA`, `AYESHA`, `RAYYAN`
- Student password: `1122` for each demo student

Windows PowerShell (set the author demo password for this terminal session):
```powershell
$env:AUTHOR_USERNAME="MdAzeem"
$env:AUTHOR_PASSWORD="Azeem@1122"
mvn spring-boot:run
```

Linux/macOS:
```bash
export AUTHOR_USERNAME='MdAzeem'
export AUTHOR_PASSWORD='Azeem@1122'
mvn spring-boot:run
```

Local H2 data is saved under `./data/`. The H2 learning console is available at http://localhost:8080/h2-console (JDBC URL: `jdbc:h2:file:./data/nandigram_portal`, user `sa`, blank password).

### Optional PostgreSQL
Set `DATABASE_URL` to a JDBC URL such as `jdbc:postgresql://localhost:5432/nandigram_portal`, `DB_USER` and `DB_PASSWORD` to your database credentials, and `DB_DRIVER=org.postgresql.Driver` before starting the app.

## Deploy to Render
1. Push this folder to a GitHub repository.
2. In Render choose **New + → Blueprint** and connect that repository.
3. Render reads `render.yaml` to create the web service and PostgreSQL database. Check the available plan/pricing and persistent-disk availability in your account before deploying.
4. Set `AUTHOR_PASSWORD` in the Render service's Environment page to a strong password.
5. Deploy and open the provided URL.

If the database already exists under another Render name, update the `fromDatabase` name in `render.yaml` to match. Database availability and persistent disk support depend on the hosting plan.

## How the database works (viva)
- **PostgreSQL** is the database; it stores student profile details, marks and file metadata after the app restarts.
- **Spring Data JPA** connects Java classes to database tables.
- **Student.java** is an Entity: one Java object represents one row in the `students` table.
- **StudentRepository.java** performs database operations such as find, save and exists.
- `spring.jpa.hibernate.ddl-auto=update` automatically creates/updates the table for this learning project.
- Student passwords are stored as BCrypt hashes rather than plain text.
- Uploaded file contents remain in the uploads folder; the database keeps each file's name, type and download metadata.
- The seeded demo student accounts are created only when missing. Change their passwords before using real/private data.

## Important limitations
This is a learning/demo project, not ready for real confidential college records. For production, add proper password reset, CSRF protection, secure session cookie settings, upload malware scanning, backups, audit logs and a database migration tool. Files need persistent storage to survive hosting restarts/redeployments.
